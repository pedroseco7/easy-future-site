
$(document).ready(function() {

    //animação
    (function($) {
      $.fn.writeText = function(content) {
          var contentArray = content.split(""),
              current = 0,
              elem = this;
          setInterval(function() {
              if(current < contentArray.length) {
                  elem.text(elem.text() + contentArray[current++]);
              }
          }, 80);
      };
      
    })(jQuery);
  
    // texto para o estilo "máquina de escrever"
    $("#holder").writeText("DESLIZA PARA SABERES MAIS SOBRE NÓS!");
  
    new WOW().init();
      
    // deslizar o body para cima e para baixo em 285px
    //para baixo
    var main = function() {
      $('.fa-bars').click(function() {
        $('.nav-screen').animate({
          right: "0px"
        }, 200);
  
        $('body').animate({
          right: "285px"
        }, 200);
      });
  
      // para cima
      $('.fa-times').click(function() {
        $('.nav-screen').animate({
          right: "-285px"
        }, 200);
  
        $('body').animate({
          right: "0px"
        }, 200);
      });
  
      $('.nav-links a').click(function() {
        $('.nav-screen').animate({
          right: "-285px"
        }, 500);
  
        $('body').animate({
          right: "0px"
        }, 500);
      });
    };
  
    $(document).ready(main);
    
    // scroll da pagina inicial
  
    $('#fullpage').fullpage({
      scrollBar: true,
      responsiveWidth: 400,
      navigation: true,
      navigationTooltips: ['INÍCIO', 'QUEM SOMOS', 'SOBRE NÓS', 'CONTACTOS'],
      menu: '#myMenu',
      fitToSection: false,
  
      afterLoad: function ( anchorLink, index){
        var loadedSection = $(this);
  
  
        if(index==1){
          //dar efeito à seta
          $('.fa-chevron-down').each(function(){
            $(this).css('opacity','1')
          });
          $('.header-links a').each(function(){
            $(this).css('color','white')
          });
        }
  
        else if(index!=1){
          $('.header-links a').each(function(){
            $(this).css('color','black')
          });
        }  
      }
    });
   
  
    // mover a secção para baixo
    $(document).on('click', '#moveDown', function(){
      $.fn.fullpage.moveSectionDown();
    });
  
    
    $(document).on('click', '#skills', function(){
      $.fn.fullpage.moveTo(2);
    });
  
    $(document).on('click', '#sobrenos', function(){
      $.fn.fullpage.moveTo(3);
    });
  
    $(document).on('click', '#contact', function(){
      $.fn.fullpage.moveTo(4);
    });
  
    // deslizamento da pagina
    $(function() {
      $('a[href*=#]:not([href=#])').click(function() {
        if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
          var target = $(this.hash);
          target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
          if (target.length) {
            $('html,body').animate({
              scrollTop: target.offset().top
            }, 700);
            return false;
          }
        }
      });
    });
  });